﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        // سجل العمليات
        public static List<HistoryItem> History = new List<HistoryItem>();

        public Form1()
        {
            InitializeComponent();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
        }

        private void button3_Click(object sender, EventArgs e)
        {
        }

        // اختيار ملف التشفير
        private void button6_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfile = new OpenFileDialog();

            openfile.Title = "اختر ملف";
            openfile.Filter = "كل الملفات (*.*)|*.*";

            if (openfile.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = openfile.FileName;
            }
        }

        // تشفير الملف
        private void button8_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("الرجاء اختيار ملف أولاً");
                return;
            }

            if (!File.Exists(textBox1.Text))
            {
                MessageBox.Show("الملف غير موجود");
                return;
            }

            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("الرجاء إدخال كلمة مرور");
                return;
            }

            try
            {
                encryptfile enc = new encryptfile(textBox2.Text);
                enc.encrypt(textBox1.Text);

                // إضافة العملية إلى السجل
                History.Add(new HistoryItem
                {
                    FileName = Path.GetFileName(textBox1.Text),
                    Operation = "تشفير",
                    Date = DateTime.Now,
                    Status = "نجاح"
                });

                MessageBox.Show("تم تشفير الملف بنجاح");
            }
            catch (Exception ex)
            {
                // تسجيل العملية الفاشلة
                History.Add(new HistoryItem
                {
                    FileName = Path.GetFileName(textBox1.Text),
                    Operation = "تشفير",
                    Date = DateTime.Now,
                    Status = "فشل"
                });

                MessageBox.Show(
                    "حدث خطأ أثناء التشفير:\n" + ex.Message);
            }
        }

        // فك تشفير الملف
        private void button7_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox4.Text))
            {
                MessageBox.Show("الرجاء اختيار ملف أولاً");
                return;
            }

            if (!File.Exists(textBox4.Text))
            {
                MessageBox.Show("الملف غير موجود");
                return;
            }

            if (string.IsNullOrWhiteSpace(textBox3.Text))
            {
                MessageBox.Show("الرجاء إدخال كلمة مرور");
                return;
            }

            try
            {
                encryptfile enc = new encryptfile(textBox3.Text);

                // هنا تم تصحيح الخطأ:
                // كان textBox1 والصحيح textBox4
                enc.decrypt(textBox4.Text);

                // إضافة العملية إلى السجل
                History.Add(new HistoryItem
                {
                    FileName = Path.GetFileName(textBox4.Text),
                    Operation = "فك التشفير",
                    Date = DateTime.Now,
                    Status = "نجاح"
                });

                MessageBox.Show("تم فك تشفير الملف بنجاح");
            }
            catch (Exception ex)
            {
                // تسجيل العملية الفاشلة
                History.Add(new HistoryItem
                {
                    FileName = Path.GetFileName(textBox4.Text),
                    Operation = "فك التشفير",
                    Date = DateTime.Now,
                    Status = "فشل"
                });

                MessageBox.Show(
                    "فشل فك التشفير: كلمة المرور غير صحيحة أو الملف غير مشفر بهذا البرنامج.");
            }
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void label7_Click(object sender, EventArgs e)
        {
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void label3_Click(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        // اختيار ملف التشفير
        private void guna2Button5_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfile = new OpenFileDialog();

            openfile.Title = "اختر ملف";
            openfile.Filter = "كل الملفات (*.*)|*.*";

            if (openfile.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = openfile.FileName;
            }
        }

        // اختيار ملف فك التشفير
        private void guna2Button6_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfile = new OpenFileDialog();

            openfile.Title = "اختر ملف";
            openfile.Filter = "كل الملفات (*.*)|*.*";

            if (openfile.ShowDialog() == DialogResult.OK)
            {
                textBox4.Text = openfile.FileName;
            }
        }

        // زر سجل العمليات
        private void guna2Button2_Click(object sender, EventArgs e)
        {
            HistoryForm historyForm = new HistoryForm();

            historyForm.ShowDialog();
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                       "File Encryption Tool\n\n" +
        "برنامج لتشفير وفك تشفير الملفات.\n" +
        "يساعدك على حماية ملفاتك وبياناتك.\n\n");


        }
    }
}