﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Security.Cryptography;

namespace WindowsFormsApplication1
{
   public class encryptfile
    {
        public TripleDESCryptoServiceProvider des = new TripleDESCryptoServiceProvider();
        public encryptfile(string key)
        {
            //كود كلمة السر

            using (SHA256 sha = SHA256.Create())
            {
                byte[]hash=sha.ComputeHash(Encoding.UTF8.GetBytes(key));
                byte[] tripledeskey = new byte[24];
                Array.Copy(hash, tripledeskey, 24);
                des.Key = tripledeskey;
                des.Mode = CipherMode.ECB;
                des.Padding = PaddingMode.PKCS7;
            }

        }
        //دالة التشفير
       public void encrypt(string filepath)
        {
            byte[] bytes = File.ReadAllBytes(filepath);
            byte[] ebytes = des.CreateEncryptor().TransformFinalBlock(bytes, 0, bytes.Length);
            File.WriteAllBytes(filepath, ebytes);
        }
        //داله فك التشفير
        public void decrypt(string filepath)
        {
            byte[] bytes = File.ReadAllBytes(filepath);
            byte[] dbytes = des.CreateDecryptor().TransformFinalBlock(bytes, 0, bytes.Length);
            File.WriteAllBytes(filepath, dbytes);
        }
    }
}
