﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class HistoryForm : Form
    {
        public HistoryForm()
        {
            InitializeComponent();

            LoadHistory();
        }

        private void LoadHistory()
        {
            list.Items.Clear();

            foreach (HistoryItem x in Form1.History)
            {
                ListViewItem item = new ListViewItem(x.FileName);

                item.SubItems.Add(x.Operation);
                item.SubItems.Add(
                    x.Date.ToString("yyyy-MM-dd HH:mm"));
                item.SubItems.Add(x.Status);

                list.Items.Add(item);
            }
        }
    }
}