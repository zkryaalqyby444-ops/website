﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;

namespace WindowsFormsApplication1
{
    public class HistoryItem
    {
        public string FileName { get; set; }
        public string Operation { get; set; }
        public DateTime Date { get; set; }
        public string Status { get; set; }
    }
}